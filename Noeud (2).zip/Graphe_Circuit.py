import networkx as nx
import Noeud

def add_nodes_circuit(graph  :nx.Graph): # entre tous les noeuds du circuit

    n = Noeud.Noeud(type_= Noeud.Type.VCC, position = "p4")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.HOLE, position = "h4")
    G.add_node(n,type=n.type)

    n = Noeud.Noeud(type_= Noeud.Type.PIN_INPUT, position = "e7")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_INPUT, position = "e8")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_OUTPUT, position = "e9", func = "NAND")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_INPUT, position = "e10")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_INPUT, position = "e11")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_OUTPUT, position = "e12", func = "NAND")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_GND, position = "e13")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_VCC, position = "f7")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_INPUT, position = "f8")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_INPUT, position = "f9")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_OUTPUT, position = "f10", func = "NAND")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_INPUT, position = "f11")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_INPUT, position = "f12")
    G.add_node(n,type=n.type)
    n = Noeud.Noeud(type_= Noeud.Type.PIN_OUTPUT, position = "f13", func = "NAND")
    G.add_node(n,type=n.type)

def is_chip_powered(graph  :nx.Graph):
    pin_vcc_gnd = [n for n in graph.nodes if n.type in [Noeud.Type.PIN_VCC, Noeud.Type.PIN_GND]]
    connected=[]
    not_connected=[]

    for n in pin_vcc_gnd:
        if n.type == Noeud.Type.VCC:
            if nx.has_path(G,n,Noeud.Type.VCC):  
                connected.append(n)
            else:
                not_connected.append(n)
        else: # n.type == Noeud.Type.VCC:
            if nx.has_path(G,n,Noeud.Type.GND):  
                connected.append(n)
            else:
                not_connected.append(n)

    return (connected,not_connected)

# Création du graphe de noeuds 
G = nx.Graph()
print(type(G))
add_nodes_circuit(G)
connected, not_connected = is_chip_powered(G)
print("***************Les pins connectes***************************")
for n in connected:
    print(n)
print("***************Les pins non connectes***************************")
for n in not_connected:
    print(n)


# def detect_short_circuits(graph):
#     """
#     Détecte la présence d'un court-circuit entre VCC et GND.
#     """
#     if nx.has_path(graph, "VCC", "GND"):
#         paths = list(nx.all_shortest_paths(graph, "VCC", "GND"))
#         for path in paths:
#             node_types = [graph.nodes[node]["type"] for node in path[1:-1] if "type" in graph.nodes[node]]
#             if all(nt not in ["INPUT", "OUTPUT", "CLOCK"] for nt in node_types):  # Un chemin direct sans composant autres
#                 print(f"⚠️ Court-circuit détecté entre VCC et GND via {path}")
#                 return
#     print("✅ Aucun court-circuit détecté.")


