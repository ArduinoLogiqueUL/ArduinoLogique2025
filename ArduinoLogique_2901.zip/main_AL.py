import tkinter as tk
import component_AL as comp



win = tk.Tk()
win.title("Laboratoire virtuel de circuit logique - GIF-1002")
win.geometry("1500x800")  # Initial window size
#win.minsize(3456, 2234)    # Set minimal window size 3456 × 2234) 1500,800
win.resizable(True, True)  # Disabling window resizing
win.configure(bg="#333333")  # Setting consistent background color

canvas = tk.Canvas(win, width=1500, height=800)
canvas.pack()

comp.workshop.set_canvas(canvas)
bredboard = comp.board()
bredboard.draw(3,3)

h = comp.hole()
h.draw(4,4,scale=1)
h.draw(4,5,scale=1)


win.mainloop()