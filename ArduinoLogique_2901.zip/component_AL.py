from abc import ABC, abstractmethod
import gfx_AL as gfx


class grid:  
    _instance = None 
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(grid, cls).__new__(cls)
        return cls._instance

    def __init__(self,canvas=None, w_grid_size=15, h_grid_size=15):  # corriger pour éviter plusieurs init!!!!
        self.w_grid_size = w_grid_size
        self.h_grid_size = h_grid_size   # hauteur de référence du nouveau système de coordonnées(basé sur les trous)
        self.canvas = canvas
        
    def set_canvas(self,canvas):
        self.canvas = canvas
        
workshop = grid()

class component(ABC):
   
    def __init__(self):
        super().__init__()
        self.workshop= workshop
        
    def wh2xy(self,w,h):
        return w * self.workshop.w_grid_size, h * self.workshop.h_grid_size
    
    @abstractmethod
    def draw(self, x_pos, y_pos) :
        pass
    

    
class hole(component):

    def draw(self, x_pos, y_pos, scale=1):
        x, y = self.wh2xy(x_pos, y_pos)
        gfx.draw_square_hole( self.workshop.canvas, x, y, scale, space = 9)
        
class board(component):
    def __init__(self, w_board=67, h_board=23):
        super().__init__()
        self.w_board, self.h_board = self.wh2xy( w_board, h_board)
        
    def draw(self,x_pos,y_pos,scale=1):
        x, y = self.wh2xy(x_pos, y_pos)
        gfx.draw_board(self.workshop.canvas, x, y,self.h_board, self.w_board, scale)